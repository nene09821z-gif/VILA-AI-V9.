VILA AI SERVER V8

1) Cai Node.js >= 18.
2) Dat GEMINI_API_KEY vao bien moi truong hoac file .env.
3) Mo terminal tai thu muc nay:
   npm install
   npm start
4) Mo http://127.0.0.1:8787

API key duoc giu o server, khong can nhung vao HTML.
Server lang nghe 0.0.0.0 de co the truy cap tu thiet bi khac trong cung mang LAN.

Luu y: server khong tu dong vuot quota Gemini. Neu project het quota, server se fallback va tra loi loi 429 ro rang.
